package com.punjabibooktranslator.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.punjabibooktranslator.data.ThemeMode

private val LightColors = lightColorScheme(
    primary = Color(0xFF7A4E2D), onPrimary = Color.White,
    primaryContainer = Color(0xFFF0DFD0), onPrimaryContainer = Color(0xFF2B170A),
    secondary = Color(0xFF6F5B4B), onSecondary = Color.White,
    background = Color(0xFFFBF8F3), onBackground = Color(0xFF1F1B16),
    surface = Color(0xFFFBF8F3), onSurface = Color(0xFF1F1B16),
    surfaceVariant = Color(0xFFEDE4DA), onSurfaceVariant = Color(0xFF4F4539),
    outline = Color(0xFF81756A), outlineVariant = Color(0xFFD3C4B5),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF6F1EA),
    surfaceContainer = Color(0xFFF1EBE3), surfaceContainerHigh = Color(0xFFEBE5DC),
    surfaceContainerHighest = Color(0xFFE5DFD6),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFE8B98F), onPrimary = Color(0xFF442B12),
    primaryContainer = Color(0xFF5E4127), onPrimaryContainer = Color(0xFFFFDCBE),
    secondary = Color(0xFFD7C3B3), onSecondary = Color(0xFF3B2E22),
    background = Color(0xFF14120F), onBackground = Color(0xFFE6E1DA),
    surface = Color(0xFF14120F), onSurface = Color(0xFFE6E1DA),
    surfaceVariant = Color(0xFF4F4539), onSurfaceVariant = Color(0xFFD3C4B5),
    outline = Color(0xFF9C8F80), outlineVariant = Color(0xFF4F4539),
    surfaceContainerLowest = Color(0xFF0F0D0A), surfaceContainerLow = Color(0xFF1B1814),
    surfaceContainer = Color(0xFF1F1C18), surfaceContainerHigh = Color(0xFF2A2621),
    surfaceContainerHighest = Color(0xFF35312B),
)

@Composable
fun BookTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
