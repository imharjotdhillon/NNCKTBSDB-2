@file:OptIn(ExperimentalMaterial3Api::class)

package com.punjabibooktranslator.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.punjabibooktranslator.AppContainer
import com.punjabibooktranslator.data.ReaderPrefs
import com.punjabibooktranslator.data.ThemeMode
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(container: AppContainer) {
    val prefs by container.prefs.prefs.collectAsStateWithLifecycle(initialValue = ReaderPrefs())
    val scope = rememberCoroutineScope()
    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            Section("Appearance") {
                ThemeModeSelector(prefs.themeMode) { mode -> scope.launch { container.prefs.update { copy(themeMode = mode) } } }
                Text(
                    "Font size, spacing, margins and brightness are changed from the reader's settings button.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Section("Privacy") {
                Text(
                    "Your books, extracted text and reading progress are stored only on this device. The app makes no network requests " +
                        "of its own and uploads nothing. Internet access exists only for the in-app Gemini window, which shows Google's " +
                        "website like a browser; text reaches Gemini only when you paste it there yourself. Backups and exports are " +
                        "files you choose where to save.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Section("Backup") {
                BackupSection(container)
            }
            Section("About") {
                Text("Punjabi Book Translator 0.5.0 (reader, translation, queue, glossary, verification, export, backup)", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Open-source components: Noto Sans Gurmukhi (SIL Open Font License 1.1), Jsoup (MIT), " +
                        "PDFBox-Android (Apache 2.0), AndroidX and Jetpack Compose (Apache 2.0). " +
                        "The font license text is bundled in the app's assets.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        content()
    }
}

@Composable
fun ThemeModeSelector(mode: ThemeMode, onChange: (ThemeMode) -> Unit) {
    val options = listOf(ThemeMode.SYSTEM to "System", ThemeMode.LIGHT to "Light", ThemeMode.DARK to "Dark")
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
        options.forEachIndexed { i, (m, label) ->
            SegmentedButton(
                selected = mode == m,
                onClick = { onChange(m) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size),
            ) { Text(label) }
        }
    }
}

@Composable
private fun BackupSection(container: AppContainer) {
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var report by remember { mutableStateOf<List<String>?>(null) }
    var overwrite by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { busy = true; message = container.backup.write(uri) ?: "Backup saved."; busy = false }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { busy = true; report = container.backup.restore(uri, overwrite); busy = false }
    }
    Text(
        "A backup file holds your translations, glossary and chapter summaries for every imported book. It does not contain the books " +
            "themselves. To restore on another device, import the same book files first, then restore.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Button(onClick = { create.launch("punjabi-book-translator-backup.json") }, enabled = !busy) { Text("Create backup") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(overwrite, { overwrite = it })
        Text("When restoring, replace translations that differ (old text is kept in history)", style = MaterialTheme.typography.bodySmall)
    }
    OutlinedButton(onClick = { open.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }, enabled = !busy) { Text("Restore from backup") }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    report?.let { lines ->
        AlertDialog(
            onDismissRequest = { report = null }, title = { Text("Restore result") },
            text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) { lines.forEach { Text(it) } } },
            confirmButton = { TextButton(onClick = { report = null }) { Text("Close") } },
        )
    }
}
