# Phase 1: shrinking disabled. Add keep rules for Room, PDFBox-Android and Jsoup before enabling minify.
